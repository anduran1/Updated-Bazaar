package dev.bazaar.autoflip;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Client configuration for live in-game GUI execution. */
public final class FlipConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("autoflip.json");
    public double taxRate = 0.0125;
    public double budgetFraction = 0.20;
    public double coinReserve = 100_000;
    public double minimumRoi = 0.018;
    public double maximumSpread = 0.22;
    public double maximumPriceDeviation = 0.08;
    public long minimumWeeklyVolume = 10_000;
    public int minimumOrderCount = 12;
    public int maxQuantity = 20_000;
    public int orderPollSeconds = 18;
    public int uiDelayMillis = 1100;
    public String marketUrl = "https://api.hypixel.net/v2/skyblock/bazaar";
    /** Bazaar product ids the bot will never pick. Edit in config/autoflip.json. */
    public List<String> excludedProducts = new ArrayList<>(List.of(
        "ESSENCE_WITHER", "ESSENCE_SPIDER", "ESSENCE_UNDEAD", "ESSENCE_DRAGON",
        "ESSENCE_GOLD", "ESSENCE_DIAMOND", "ESSENCE_ICE"));
    public String allowedServerHost = "mc.hypixel.net";

    public static FlipConfig load() {
        try {
            if (Files.exists(PATH)) try (Reader r = Files.newBufferedReader(PATH)) {
                FlipConfig config = GSON.fromJson(r, FlipConfig.class);
                if (config != null) { config = config.validated(); config.save(); return config; }
            }
        } catch (Exception e) {
            System.err.println("[AutoFlip] Invalid config: " + e.getMessage());
        }
        FlipConfig c = new FlipConfig();
        c.save();
        return c;
    }
    public void save() {
        try {
            Files.createDirectories(PATH.getParent());
            try (Writer w = Files.newBufferedWriter(PATH)) { GSON.toJson(this, w); }
        } catch (Exception e) { System.err.println("[AutoFlip] Config save failed: " + e.getMessage()); }
    }
    private FlipConfig validated() {
        taxRate = clamp(taxRate,0,.10);
        budgetFraction = clamp(budgetFraction,.01,.50);
        coinReserve = Math.max(0,coinReserve);
        minimumRoi = clamp(minimumRoi,.001,1);
        maximumSpread = clamp(maximumSpread, minimumRoi+taxRate,.50);
        maximumPriceDeviation = clamp(maximumPriceDeviation,.005,.50);
        minimumWeeklyVolume = Math.max(1,minimumWeeklyVolume);
        minimumOrderCount = Math.max(1,minimumOrderCount);
        maxQuantity = Math.max(1,Math.min(maxQuantity,100000));
        orderPollSeconds = Math.max(8,Math.min(180,orderPollSeconds));
        uiDelayMillis = Math.max(500,Math.min(5000,uiDelayMillis));
        marketUrl = "https://api.hypixel.net/v2/skyblock/bazaar";
        if (excludedProducts == null) excludedProducts = new ArrayList<>();
        if (allowedServerHost == null || allowedServerHost.isBlank()) allowedServerHost = "mc.hypixel.net";
        return this;
    }
    public boolean isExcluded(String productId) {
        if (excludedProducts == null || productId == null) return false;
        for (String e : excludedProducts)
            if (e != null && e.trim().equalsIgnoreCase(productId)) return true;
        return false;
    }
    private static double clamp(double x,double lo,double hi){return Math.max(lo,Math.min(hi,x));}
}
