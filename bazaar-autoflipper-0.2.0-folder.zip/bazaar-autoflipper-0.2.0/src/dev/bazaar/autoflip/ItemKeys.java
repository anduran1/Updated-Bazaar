package dev.bazaar.autoflip;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Maps Bazaar product ids to the names/NBT the game actually shows. Pure Java (unit-testable).
 * Product ids and in-game names diverge for legacy ids (LOG:1), enchanted books, essences, etc.
 */
public final class ItemKeys {
    private static final Pattern NBT_ID = Pattern.compile("(?:^|[{,\\s])\"?id\"?\\s*:\\s*\"([^\"]+)\"");
    private static final String[] ROMAN = {"", "I","II","III","IV","V","VI","VII","VIII","IX","X"};
    private static final Map<String,String> NAMES = Map.ofEntries(
        Map.entry("LOG","Oak Wood"), Map.entry("LOG:1","Spruce Wood"), Map.entry("LOG:2","Birch Wood"),
        Map.entry("LOG:3","Jungle Wood"), Map.entry("LOG_2","Acacia Wood"), Map.entry("LOG_2:1","Dark Oak Wood"),
        Map.entry("INK_SACK","Ink Sack"), Map.entry("INK_SACK:3","Cocoa Beans"), Map.entry("INK_SACK:4","Lapis Lazuli"),
        Map.entry("PORK","Raw Porkchop"), Map.entry("MUTTON","Raw Mutton"), Map.entry("RABBIT","Raw Rabbit"),
        Map.entry("RAW_FISH","Raw Fish"), Map.entry("RAW_FISH:1","Raw Salmon"),
        Map.entry("RAW_FISH:2","Clownfish"), Map.entry("RAW_FISH:3","Pufferfish"),
        Map.entry("CARROT_ITEM","Carrot"), Map.entry("POTATO_ITEM","Potato"), Map.entry("MELON","Melon Slice"),
        Map.entry("NETHER_STALK","Nether Wart"), Map.entry("ENCHANTED_NETHER_STALK","Enchanted Nether Wart"),
        Map.entry("QUARTZ","Nether Quartz"), Map.entry("MITHRIL_ORE","Mithril"),
        Map.entry("ENDER_STONE","End Stone"), Map.entry("ENCHANTED_ENDSTONE","Enchanted End Stone"),
        Map.entry("WATER_LILY","Lily Pad"), Map.entry("ENCHANTED_WATER_LILY","Enchanted Lily Pad"),
        Map.entry("HUGE_MUSHROOM_1","Brown Mushroom Block"), Map.entry("HUGE_MUSHROOM_2","Red Mushroom Block"),
        Map.entry("ENCHANTED_HUGE_MUSHROOM_1","Enchanted Brown Mushroom Block"),
        Map.entry("ENCHANTED_HUGE_MUSHROOM_2","Enchanted Red Mushroom Block"),
        Map.entry("SNOW_BALL","Snowball"), Map.entry("CLAY_BALL","Clay"), Map.entry("SAND:1","Red Sand"),
        Map.entry("ENCHANTED_COCOA","Enchanted Cocoa Bean"), Map.entry("ENCHANTED_SALMON","Enchanted Raw Salmon")
    );
    private ItemKeys() { }

    private static String title(String raw) {
        StringBuilder b = new StringBuilder();
        for (String p : raw.replace('_', ' ').toLowerCase(Locale.ROOT).split(" ")) if (!p.isBlank()) {
            if (!b.isEmpty()) b.append(' ');
            b.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1));
        }
        return b.toString();
    }
    private static String roman(String level) {
        try { int n = Integer.parseInt(level); return n >= 1 && n < ROMAN.length ? ROMAN[n] : level; }
        catch (NumberFormatException e) { return level; }
    }
    /** Enchant book id -> {name words, level} or null. e.g. ENCHANTMENT_ULTIMATE_WISE_1 -> {"ultimate_wise","1"}. */
    private static String[] enchant(String id) {
        if (!id.startsWith("ENCHANTMENT_")) return null;
        String rest = id.substring("ENCHANTMENT_".length());
        int cut = rest.lastIndexOf('_');
        if (cut <= 0) return null;
        return new String[] { rest.substring(0, cut).toLowerCase(Locale.ROOT), rest.substring(cut + 1) };
    }
    /** All plausible in-game names, best search term first. */
    public static List<String> names(String id) {
        Set<String> out = new LinkedHashSet<>();
        String known = NAMES.get(id);
        if (known != null) out.add(known);
        String[] e = enchant(id);
        if (e != null) {
            String base = title(e[0]);
            String lvl = roman(e[1]);
            if (e[0].startsWith("ultimate_")) out.add(title(e[0].substring(9)) + " " + lvl); // shown without "Ultimate"
            out.add(base + " " + lvl);
        } else if (id.startsWith("ESSENCE_")) {
            out.add(title(id.substring(8)) + " Essence");
        }
        out.add(title(id.contains(":") ? id.substring(0, id.indexOf(':')) : id));
        return new ArrayList<>(out);
    }
    public static String primaryName(String id) { return names(id).get(0); }
    private static String norm(String s) { return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", ""); }
    public static boolean nameMatches(String title, String id) {
        String t = norm(title);
        for (String n : names(id)) if (t.equals(norm(n))) return true;
        return false;
    }
    /** The SkyBlock item id from a stack's custom-data NBT text, or null. */
    public static String nbtId(String customData) {
        if (customData == null) return null;
        Matcher m = NBT_ID.matcher(customData);
        return m.find() ? m.group(1) : null;
    }
    /**
     * True if this stack is the given product. NBT id wins; enchant books are matched by
     * their enchantment tag; display-name aliases are the fallback.
     */
    public static boolean stackMatches(String hoverName, String customData, String productId) {
        String nbt = nbtId(customData);
        String[] e = enchant(productId);
        if (e != null && customData != null) {
            String flat = customData.replace("\"", "").replace(" ", "").toLowerCase(Locale.ROOT);
            if (flat.matches(".*[{,]" + Pattern.quote(e[0] + ":" + e[1]) + "[,}].*")) return true;
        }
        if (nbt != null) {
            if (nbt.equals(productId)) return true;
            int c = productId.indexOf(':');
            if (c > 0 && nbt.equals(productId.substring(0, c)) && hoverName != null && nameMatches(hoverName, productId)) return true;
        }
        return hoverName != null && nameMatches(hoverName, productId);
    }
}
