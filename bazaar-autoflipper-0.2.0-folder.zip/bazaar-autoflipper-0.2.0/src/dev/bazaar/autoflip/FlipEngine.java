package dev.bazaar.autoflip;

import java.util.Locale;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;

/**
 * Real in-game GUI state machine for the SkyBlock Bazaar.
 * A purchase is never issued twice because the GUI looked unexpected.
 */
final class FlipEngine {
    private enum Step {
        CHOOSE, OPEN_BUY, SEARCH_BUY, CLICK_BUY, AMOUNT, BUY_PRICE, CONFIRM_BUY,
        OPEN_BUY_ORDERS, MANAGE_BUY, CHECK_BUY,
        OPEN_SELL, SEARCH_SELL, CLICK_SELL, SELL_PRICE, CONFIRM_SELL,
        OPEN_SELL_ORDERS, MANAGE_SELL, CHECK_SELL,
        PAUSED
    }
    private final Minecraft mc = Minecraft.getInstance();
    private final HttpGateway gateway = new HttpGateway();
    private final FlipConfig cfg;
    private final Consumer<String> status;
    private final TradeJournal store = new TradeJournal();
    private TradeJournal.Entry journal;
    private MarketModel snapshot, previous;
    private CompletableFuture<MarketModel> network;
    private long marketRequestAt, lastMarketAt;
    private long nextStepAt, stepSince;
    private boolean enabled;
    private Step step=Step.CHOOSE;
    private MarketModel.Opportunity candidate;
    private long intendedQuantity;
    private long lastWaitingNotice;

    FlipEngine(FlipConfig cfg, Consumer<String> status) {
        this.cfg=cfg;
        this.status=status;
        journal=store.load();
    }
    void toggle() {
        enabled=!enabled;
        if (!enabled) { status.accept("OFF. Pending server orders remain open; no clicks sent."); return; }
        if (!serverAllowed()) {
            enabled=false;
            status.accept(HostMatch.blockedMessage(serverName(), cfg.allowedServerHost));
            return;
        }
        if (journal.side != TradeJournal.Side.NONE) {
            if (!serverName().equalsIgnoreCase(journal.serverHost)) {
                enabled=false;
                status.accept("Journal belongs to another server. Resolve config/autoflip-order.json manually.");
                return;
            }
            switch(journal.side) {
                case BUY -> move(Step.OPEN_BUY_ORDERS,0);
                case HOLD -> move(Step.OPEN_SELL,0);
                case SELL -> move(Step.OPEN_SELL_ORDERS,0);
                default -> move(Step.CHOOSE,0);
            }
            status.accept("ON: resuming saved " + journal.side + " for " + journal.productId);
        } else {
            move(Step.CHOOSE,0);
            status.accept("ON: real Bazaar GUI. Waiting for price snapshots.");
        }
    }
    void tick() {
        if (!enabled) return;
        if (!serverAllowed() || mc.player == null || mc.level == null) {
            pause("Disconnected or server changed");
            return;
        }
        updateMarket();
        long now=System.currentTimeMillis();
        if (now < nextStepAt || step==Step.PAUSED) return;
        try {
            if (step!=Step.CHOOSE && now-stepSince>24000 && !orderWaitingStep()) {
                pause("No expected Bazaar GUI after 24s at " + step + "; use F8 diagnostic");
                return;
            }
            switch(step) {
                case CHOOSE -> choose();
                case OPEN_BUY -> openSearch(false);
                case SEARCH_BUY -> chooseProduct(false);
                case CLICK_BUY -> clickNamed("create buy order",Step.AMOUNT);
                case AMOUNT -> chooseAmount();
                case BUY_PRICE -> clickPrice("top order +0.1","top order + 0.1",Step.CONFIRM_BUY);
                case CONFIRM_BUY -> confirmBuy();
                case OPEN_BUY_ORDERS -> openOrders(Step.MANAGE_BUY);
                case MANAGE_BUY -> clickNamed("manage orders",Step.CHECK_BUY);
                case CHECK_BUY -> checkOrders(true);
                case OPEN_SELL -> openSearch(true);
                case SEARCH_SELL -> chooseProduct(true);
                case CLICK_SELL -> clickNamed("create sell offer",Step.SELL_PRICE);
                case SELL_PRICE -> clickPrice("best offer -0.1","best offer - 0.1",Step.CONFIRM_SELL);
                case CONFIRM_SELL -> confirmSell();
                case OPEN_SELL_ORDERS -> openOrders(Step.MANAGE_SELL);
                case MANAGE_SELL -> clickNamed("manage orders",Step.CHECK_SELL);
                case CHECK_SELL -> checkOrders(false);
                case PAUSED -> { }
            }
        } catch (RuntimeException e) { pause(e.getMessage()==null?e.toString():e.getMessage()); }
    }
    private void updateMarket() {
        long now=System.currentTimeMillis();
        if (network == null && now-lastMarketAt>=65000) {
            marketRequestAt=now;
            lastMarketAt=now;
            network=CompletableFuture.supplyAsync(() -> {
                try { return MarketModel.from(gateway.read(cfg.marketUrl)); }
                catch (Exception e) { throw new CompletionException(e); }
            });
        }
        if (network!=null && network.isDone()) {
            try {
                MarketModel next=network.join();
                if (Math.abs(now-next.updatedAt)>180000) throw new IllegalStateException("stale API timestamp");
                previous=snapshot;
                snapshot=next;
            } catch (RuntimeException e) { status.accept("Market refresh failed (no new buys): " + e.getMessage()); }
            network=null;
        }
        if (network!=null && now-marketRequestAt>30000) {
            network.cancel(true); network=null;
        }
    }
    private boolean orderWaitingStep() { return step==Step.CHECK_BUY || step==Step.CHECK_SELL; }
    private void choose() {
        if (journal.side!=TradeJournal.Side.NONE) { pause("Pending trade detected; will not start another"); return; }
        if (snapshot==null || previous==null || System.currentTimeMillis()-snapshot.updatedAt>180000) return;
        OptionalDouble purse=AccountReader.purse(mc);
        if (purse.isEmpty()) {
            if (System.currentTimeMillis()-lastWaitingNotice>30000) {
                status.accept(AccountReader.noPurseMessage());
                lastWaitingNotice=System.currentTimeMillis();
            }
            return;
        }
        Optional<MarketModel.Opportunity> o=snapshot.best(purse.getAsDouble(),cfg,previous,
            id -> AccountReader.count(mc,id)==0);
        if (o.isEmpty()) return;
        candidate=o.get();
        intendedQuantity=candidate.quantity();
        status.accept("Selected "+candidate.productId()+"; up to "+intendedQuantity+" items; budget from purse " + Math.round(purse.getAsDouble()));
        move(Step.OPEN_BUY,0);
    }
    private void openSearch(boolean selling) {
        String id= selling ? journal.productId : candidate.productId();
        if (selling) {
            long held=AccountReader.count(mc,id);
            if (held<journal.quantity) {
                // The collection packet may be in flight; wait rather than listing wrong inventory.
                if (System.currentTimeMillis()-stepSince>18000) pause("Bought items not found in inventory; manual reconciliation required");
                else nextStepAt=System.currentTimeMillis()+1200;
                return;
            }
            if (held!=journal.quantity) { pause("Inventory contains extra "+id+" items; refusing to sell unrelated items"); return; }
        }
        // Server must supply the /bz <search> command and a Bazaar search GUI.
        GuiAccess.command(mc,"bz "+MenuRules.productName(id));
        move(selling?Step.SEARCH_SELL:Step.SEARCH_BUY,2000);
    }
    private void chooseProduct(boolean selling) {
        GuiAccess.Menu menu=GuiAccess.read(mc);
        if (menu==null) { delay(350); return; }
        String id=selling?journal.productId:candidate.productId();
        if (menu.find("create buy order")!=null || menu.find("create sell offer")!=null) {
            move(selling?Step.CLICK_SELL:Step.CLICK_BUY,700);
            return;
        }
        GuiAccess.MenuSlot found=menu.exactProduct(id);
        if (found!=null) {
            GuiAccess.left(mc,menu,found);
            move(selling?Step.CLICK_SELL:Step.CLICK_BUY,cfg.uiDelayMillis);
        } else delay(350);
    }
    private void clickNamed(String name,Step after) {
        GuiAccess.Menu m=GuiAccess.read(mc);
        if (m==null) { delay(350); return; }
        GuiAccess.MenuSlot slot=m.find(name);
        if (slot==null) { delay(350); return; }
        GuiAccess.left(mc,m,slot);
        move(after,cfg.uiDelayMillis);
    }
    private void chooseAmount() {
        GuiAccess.Menu menu=GuiAccess.read(mc);
        if (menu==null) { delay(400); return; }
        OptionalDouble purse=AccountReader.purse(mc);
        if (purse.isEmpty()) { pause("Purse disappeared before buy order"); return; }
        double limit=Math.min(intendedQuantity,Math.floor(
            Math.max(0,purse.getAsDouble()-cfg.coinReserve)*cfg.budgetFraction / candidate.bidPrice()));
        GuiAccess.MenuSlot best=null;
        int bestQty=0;
        for (GuiAccess.MenuSlot item : menu.slots()) {
            int qty=MenuRules.presetQuantity(item.name(),item.lore());
            if (qty>bestQty && qty<=limit && qty<=cfg.maxQuantity) {bestQty=qty; best=item;}
        }
        if (best!=null) {
            intendedQuantity=bestQty;
            GuiAccess.left(mc,menu,best);
            status.accept("Selecting actual GUI quantity "+bestQty);
            move(Step.BUY_PRICE,cfg.uiDelayMillis);
        } else if (System.currentTimeMillis()-stepSince>6000) pause(
            "Cannot verify a preset quantity under purse limit; no buy sent. F8 shows menu labels.");
        else delay(350);
    }
    private void clickPrice(String phraseA,String phraseB,Step after) {
        GuiAccess.Menu m=GuiAccess.read(mc);
        if (m==null) { delay(350); return; }
        GuiAccess.MenuSlot s=m.find(phraseA);
        if (s==null) s=m.find(phraseB);
        // Different menu releases may omit the decimal in their item title.
        if (s==null) { delay(350); return; }
        GuiAccess.left(mc,m,s);
        move(after,cfg.uiDelayMillis);
    }
    private void confirmBuy() {
        GuiAccess.Menu m=GuiAccess.read(mc);
        if (m==null) { delay(350); return; }
        GuiAccess.MenuSlot s=findConfirmation(m,"buy order");
        if (s==null) { delay(350); return; }
        OptionalDouble purse=AccountReader.purse(mc);
        if (purse.isEmpty() || intendedQuantity*candidate.bidPrice() >
                Math.max(0,purse.getAsDouble()-cfg.coinReserve)*cfg.budgetFraction + 1) {
            pause("Purse or budget changed before confirmation"); return;
        }
        // The journal is deliberately committed BEFORE the action. If the client
        // crashes, it will only inspect orders; it will NEVER blindly buy again.
        journal.side=TradeJournal.Side.BUY;
        journal.serverHost=serverName();
        journal.productId=candidate.productId();
        journal.quantity=intendedQuantity;
        journal.buyPrice=candidate.bidPrice();
        journal.sellPrice=candidate.askPrice();
        journal.submittedAt=System.currentTimeMillis();
        store.save(journal);
        GuiAccess.left(mc,m,s);
        status.accept("Submitted BUY order via Minecraft GUI: "+intendedQuantity+" "+journal.productId);
        move(Step.OPEN_BUY_ORDERS,3200);
    }
    private void openOrders(Step next) {
        GuiAccess.command(mc,"bz");
        move(next,1800);
    }
    private void checkOrders(boolean buying) {
        GuiAccess.Menu m=GuiAccess.read(mc);
        if (m==null) { delay(350); return; }
        GuiAccess.MenuSlot found=null;
        for (GuiAccess.MenuSlot slot:m.slots()) {
            String all=slot.all();
            if (!MenuRules.normalize(all).contains(MenuRules.normalize(MenuRules.productName(journal.productId)))) continue;
            boolean matchingSide=buying?MenuRules.buyOrder(all):MenuRules.sellOffer(all);
            if (matchingSide) {
                if (found!=null) { pause("More than one matching order; ambiguous collection"); return; }
                found=slot;
            }
        }
        if (found==null) {
            // Some servers put Buy Orders and Sell Offers on separate submenus.
            GuiAccess.MenuSlot page=m.find(buying?"buy orders":"sell offers");
            if (page!=null) {
                GuiAccess.left(mc,m,page);
                delay(cfg.uiDelayMillis);
                return;
            }
            if (System.currentTimeMillis()-stepSince>10000)
                pause("Own "+(buying?"buy":"sell")+" order not identifiable in Manage Orders. F8 dump required.");
            else delay(500);
            return;
        }
        if (!MenuRules.fullyFilled(found.all())) {
            // Leave every existing order untouched until ALL items are filled.
            if (System.currentTimeMillis()-lastWaitingNotice>60000) {
                status.accept("Waiting for "+(buying?"BUY":"SELL")+" to fill: "+journal.productId);
                lastWaitingNotice=System.currentTimeMillis();
            }
            move(buying?Step.OPEN_BUY_ORDERS:Step.OPEN_SELL_ORDERS,cfg.orderPollSeconds*1000L);
            return;
        }
        if (buying) {
            // Persist HOLD before claiming. On restart, check actual inventory.
            journal.side=TradeJournal.Side.HOLD;
            store.save(journal);
            GuiAccess.left(mc,m,found);  // collect real purchased items
            status.accept("Collected filled BUY via in-game order menu: "+journal.productId);
            move(Step.OPEN_SELL,2000);
        } else {
            // Mark completed in journal before collecting; on restart, if the
            // packet did not go through, manual reconciliation is required.
            GuiAccess.left(mc,m,found);  // collect real sold coins
            journal=new TradeJournal.Entry();
            store.save(journal);
            status.accept("Collected completed SELL proceeds; flip finished.");
            move(Step.CHOOSE,15000);
        }
    }
    private void confirmSell() {
        GuiAccess.Menu m=GuiAccess.read(mc);
        if (m==null) { delay(350); return; }
        GuiAccess.MenuSlot s=findConfirmation(m,"sell offer");
        if (s==null) { delay(350); return; }
        // Sell Offers usually take all matching items in inventory.
        long held=AccountReader.count(mc,journal.productId);
        if (held!=journal.quantity) { pause("Inventory changed before SELL confirmation"); return; }
        journal.side=TradeJournal.Side.SELL;
        journal.submittedAt=System.currentTimeMillis();
        store.save(journal);
        GuiAccess.left(mc,m,s);
        status.accept("Submitted SELL offer via Minecraft GUI for "+journal.quantity+" "+journal.productId);
        move(Step.OPEN_SELL_ORDERS,3200);
    }
    /** Accept both full-text and short confirmation buttons, but only in a confirmation screen. */
    private GuiAccess.MenuSlot findConfirmation(GuiAccess.Menu menu,String operation) {
        String title=menu.title().toLowerCase(Locale.ROOT);
        for (GuiAccess.MenuSlot slot:menu.slots()) {
            String n=slot.norm();
            if (n.contains("cancel")) continue;
            if (n.contains("confirm " + operation)) return slot;
            if (n.equals(operation) && (title.contains("confirm") ||
                slot.lore().toLowerCase(Locale.ROOT).contains("click to confirm"))) return slot;
        }
        return null;
    }
    private void delay(long ms) { nextStepAt=System.currentTimeMillis()+ms; }
    private void move(Step next,long delayMs) {
        step=next;
        stepSince=System.currentTimeMillis();
        nextStepAt=stepSince+delayMs;
    }
    private String serverName() {
        return mc.getCurrentServer()==null?"":mc.getCurrentServer().ip.toLowerCase(Locale.ROOT);
    }
    private boolean serverAllowed() {
        return HostMatch.allowed(serverName(), cfg.allowedServerHost);
    }
    private void pause(String why) {
        status.accept("PAUSED — "+why);
        dumpGui();
        enabled=false;
        move(Step.PAUSED,0);
    }
    void dumpGui() {
        GuiAccess.Menu menu=GuiAccess.read(mc);
        if (menu==null) {status.accept("F8: no container menu open"); return;}
        System.out.println("[AutoFlip] F8 DIAGNOSTIC: " + menu.title()+" id="+menu.containerId());
        for (GuiAccess.MenuSlot s:menu.slots())
            System.out.println("[AutoFlip] #"+s.index()+" "+s.name()+" | "+s.lore().replace('\n',';'));
        status.accept("F8 GUI dump written to Minecraft latest.log: "+menu.title());
    }
}
