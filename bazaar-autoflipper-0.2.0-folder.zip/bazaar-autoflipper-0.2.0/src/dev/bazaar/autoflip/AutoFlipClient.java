package dev.bazaar.autoflip;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

public final class AutoFlipClient implements ClientModInitializer {
    private static final KeyMapping.Category CATEGORY=KeyMapping.Category.register(
        Identifier.fromNamespaceAndPath("autoflip","main"));
    @Override public void onInitializeClient() {
        FlipEngine engine=new FlipEngine(FlipConfig.load(),msg->{
            Minecraft mc=Minecraft.getInstance();
            mc.execute(()->{
                if (mc.player != null) mc.player.sendSystemMessage(Component.literal("[AutoFlip] " + msg));
                System.out.println("[AutoFlip] "+msg);
            });
        });
        KeyMapping toggle=KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.autoflip.toggle",InputConstants.Type.KEYBOARD,InputConstants.KEY_C,CATEGORY));
        KeyMapping diag=KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.autoflip.diagnostic",InputConstants.Type.KEYBOARD,InputConstants.KEY_F8,CATEGORY));
        ClientTickEvents.END_CLIENT_TICK.register(mc->{
            while(toggle.consumeClick()) engine.toggle();
            while(diag.consumeClick()) engine.dumpGui();
            engine.tick();
        });
    }
}
