package dev.bazaar.autoflip;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.*;
import java.util.function.Predicate;

/** Product snapshots are public Hypixel data, not transaction/account data. */
public final class MarketModel {
    public record Product(String id, double bestBid, double bestAsk, double bidDepth,
                          double askDepth, long weeklyBidFlow, long weeklyAskFlow,
                          int bidOrders, int askOrders, double weightedBid, double weightedAsk) { }
    public record Opportunity(String productId, long quantity, double bidPrice, double askPrice,
                              double profitPerItem, double expectedTotalProfit, double score) { }

    public final long updatedAt;
    public final Map<String, Product> products;

    private MarketModel(long updatedAt, Map<String, Product> products) {
        this.updatedAt = updatedAt;
        this.products = Collections.unmodifiableMap(products);
    }

    public static MarketModel from(JsonObject root) {
        if (!root.has("success") || !root.get("success").getAsBoolean())
            throw new IllegalArgumentException("Bazaar API returned success=false");
        long ts = number(root, "lastUpdated", 0).longValue();
        JsonObject rawProducts = root.getAsJsonObject("products");
        if (rawProducts == null) throw new IllegalArgumentException("Bazaar API has no products");
        Map<String, Product> result = new HashMap<>();
        for (var entry : rawProducts.entrySet()) {
            try {
                JsonObject p = entry.getValue().getAsJsonObject();
                JsonObject q = p.getAsJsonObject("quick_status");
                JsonArray bids = p.getAsJsonArray("sell_summary"); // top buy orders
                JsonArray asks = p.getAsJsonArray("buy_summary"); // top sell offers
                if (q == null || bids == null || asks == null || bids.isEmpty() || asks.isEmpty()) continue;
                double bid = price(bids.get(0)), ask = price(asks.get(0));
                if (!(bid > 0 && ask > bid)) continue;
                double bidDepth = depthWithin(bids, bid, true);
                double askDepth = depthWithin(asks, ask, false);
                Product product = new Product(entry.getKey(), bid, ask, bidDepth, askDepth,
                    number(q,"sellMovingWeek",0).longValue(), number(q,"buyMovingWeek",0).longValue(),
                    number(q,"sellOrders",0).intValue(), number(q,"buyOrders",0).intValue(),
                    number(q,"sellPrice",bid).doubleValue(), number(q,"buyPrice",ask).doubleValue());
                result.put(entry.getKey(), product);
            } catch (RuntimeException ignored) { /* Skip malformed individual product. */ }
        }
        if (result.isEmpty()) throw new IllegalArgumentException("Bazaar API has no tradable products");
        return new MarketModel(ts, result);
    }

    public Optional<Opportunity> best(double purse, FlipConfig cfg, MarketModel previous) {
        return best(purse, cfg, previous, id -> true);
    }

    public Optional<Opportunity> best(double purse, FlipConfig cfg, MarketModel previous,
                                      Predicate<String> allowedProduct) {
        double available = Math.max(0, purse - cfg.coinReserve) * cfg.budgetFraction;
        if (available < 1) return Optional.empty();
        return products.values().stream()
            .filter(p -> !cfg.isExcluded(p.id()))
            .filter(p -> allowedProduct.test(p.id()))
            .filter(p -> previous.products.containsKey(p.id()))
            .filter(p -> stable(p, previous.products.get(p.id()), cfg))
            .map(p -> candidate(p, available, cfg))
            .flatMap(Optional::stream)
            .max(Comparator.comparingDouble(Opportunity::score));
    }

    private static boolean stable(Product now, Product before, FlipConfig cfg) {
        return Math.abs(now.bestBid - before.bestBid) / before.bestBid < cfg.maximumPriceDeviation
            && Math.abs(now.bestAsk - before.bestAsk) / before.bestAsk < cfg.maximumPriceDeviation;
    }

    private static Optional<Opportunity> candidate(Product p, double budget, FlipConfig cfg) {
        if (p.weeklyBidFlow < cfg.minimumWeeklyVolume || p.weeklyAskFlow < cfg.minimumWeeklyVolume
            || p.bidOrders < cfg.minimumOrderCount || p.askOrders < cfg.minimumOrderCount) return Optional.empty();
        double cost = round1(p.bestBid + 0.1), resale = round1(p.bestAsk - 0.1);
        if (resale <= cost || (resale - cost) / cost > cfg.maximumSpread) return Optional.empty();
        if (Math.abs(p.weightedBid - p.bestBid) / p.bestBid > cfg.maximumPriceDeviation
            || Math.abs(p.weightedAsk - p.bestAsk) / p.bestAsk > cfg.maximumPriceDeviation) return Optional.empty();
        double net = resale * (1 - cfg.taxRate) - cost;
        if (net / cost < cfg.minimumRoi) return Optional.empty();
        // Thin books and unreliable 7-day volume are heavily capped.
        double hourly = Math.min(p.weeklyBidFlow, p.weeklyAskFlow) / 168.0;
        long qty = (long)Math.floor(Math.min(Math.min(budget / cost,
                Math.min(p.bidDepth, p.askDepth) * 0.25),
                Math.min(hourly * 0.05, cfg.maxQuantity)));
        if (qty < 1) return Optional.empty();
        double profit = qty * net;
        // Prefer meaningful profits with enough flow to fill both sides.
        double score = profit * Math.log1p(hourly) / (1 + (resale - cost) / cost * 3);
        return Optional.of(new Opportunity(p.id, qty, cost, resale, net, profit, score));
    }

    public static double round1(double value) { return Math.round(value * 10.0) / 10.0; }

    private static double depthWithin(JsonArray arr, double top, boolean bids) {
        double total = 0;
        for (JsonElement e : arr) {
            double px = price(e);
            if (bids ? px < top * 0.99 : px > top * 1.01) break;
            total += number(e.getAsJsonObject(), "amount", 0).doubleValue();
        }
        return total;
    }
    private static double price(JsonElement e) { return number(e.getAsJsonObject(), "pricePerUnit", 0).doubleValue(); }
    private static Number number(JsonObject obj, String key, Number defaultValue) {
        JsonElement e = obj.get(key);
        return e == null || e.isJsonNull() ? defaultValue : e.getAsNumber();
    }
}
