package dev.bazaar.autoflip;

import java.util.Locale;

/** Server-address matching with no Minecraft dependencies. */
final class HostMatch {
    private HostMatch() { }
    private static String strip(String h) {
        h = h.trim().toLowerCase(Locale.ROOT);
        int c = h.indexOf(':');
        if (c >= 0) h = h.substring(0, c);
        while (h.endsWith(".")) h = h.substring(0, h.length() - 1);
        return h;
    }
    private static boolean isHypixel(String h) { return h.equals("hypixel.net") || h.endsWith(".hypixel.net"); }
    /** allowedList: one or more hosts separated by commas, semicolons or spaces. */
    static boolean allowed(String actual, String allowedList) {
        if (actual == null || actual.isBlank() || allowedList == null) return false;
        String host = strip(actual);
        if (host.isEmpty()) return false;
        for (String entry : allowedList.split("[,;\\s]+")) {
            String a = strip(entry);
            if (a.isEmpty()) continue;
            if (host.equals(a)) return true;
            if (a.equals("localhost") && host.equals("127.0.0.1")) return true;
            if (isHypixel(a) && isHypixel(host)) return true;
        }
        return false;
    }
    static String blockedMessage(String actual, String allowedList) {
        return "Blocked: connected to [" + actual + "] but allowedServerHost in config/autoflip.json is [" + allowedList + "]";
    }
}
