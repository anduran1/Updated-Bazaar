package dev.bazaar.autoflip;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemLore;

/** Actual client/server container packet interactions; no virtual broker. */
final class GuiAccess {
    record MenuSlot(int index, String name, String lore, int stackCount) {
        String all() { return name + "\n" + lore; }
        String norm() { return name.toLowerCase(Locale.ROOT); }
    }
    record Menu(String title, int containerId, List<MenuSlot> slots) {
        MenuSlot find(String phrase) {
            String s = phrase.toLowerCase(Locale.ROOT);
            for (MenuSlot slot : slots) if (slot.norm().contains(s)) return slot;
            return null;
        }
        MenuSlot exactProduct(String productId) {
            for (MenuSlot slot : slots)
                if (MenuRules.itemMatches(slot.name(),productId)) return slot;
            return null;
        }
    }
    static Menu read(Minecraft mc) {
        if (!(mc.gui.screen() instanceof AbstractContainerScreen<?> screen) || mc.player == null)
            return null;
        if (screen.getMenu() != mc.player.containerMenu) return null;
        List<MenuSlot> slots = new ArrayList<>();
        int count = screen.getMenu().slots.size();
        // Exclude player inventory; GUI's upper inventory typically ends at count-36.
        int upper = Math.max(0, count-36);
        for (int i=0;i<upper;i++) {
            Slot slot = screen.getMenu().slots.get(i);
            ItemStack item = slot.getItem();
            if (item.isEmpty()) continue;
            ItemLore lore = item.get(DataComponents.LORE);
            StringBuilder description = new StringBuilder();
            if (lore != null) for (Component line : lore.lines()) description.append(line.getString()).append('\n');
            slots.add(new MenuSlot(i,item.getHoverName().getString(),description.toString(),item.getCount()));
        }
        return new Menu(screen.getTitle().getString(),screen.getMenu().containerId,slots);
    }
    static void left(Minecraft mc, Menu menu, MenuSlot slot) { click(mc,menu,slot,0); }
    static void click(Minecraft mc, Menu menu, MenuSlot slot, int button) {
        if (slot == null || mc.gameMode == null || mc.player == null || mc.player.containerMenu.containerId != menu.containerId())
            throw new IllegalStateException("Stale GUI or slot");
        mc.gameMode.handleContainerInput(menu.containerId(),slot.index(),button,ContainerInput.PICKUP,mc.player);
    }
    static void command(Minecraft mc, String cmd) {
        if (mc.player == null || mc.player.connection == null)
            throw new IllegalStateException("Not connected");
        mc.player.connection.sendCommand(cmd);
    }
}
