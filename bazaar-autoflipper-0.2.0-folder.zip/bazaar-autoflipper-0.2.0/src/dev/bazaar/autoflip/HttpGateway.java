package dev.bazaar.autoflip;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

/** Public prices only. All orders are executed via Minecraft menus, not HTTP. */
final class HttpGateway {
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    JsonObject read(String url) throws Exception {
        if (!url.equals("https://api.hypixel.net/v2/skyblock/bazaar"))
            throw new IllegalArgumentException("Unexpected market endpoint");
        HttpRequest request = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(15))
            .header("Accept", "application/json")
            .header("User-Agent", "BazaarAutoFlipper-PrivateTest/0.2")
            .GET().build();
        HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) throw new IllegalStateException("Bazaar API HTTP " + response.statusCode());
        return JsonParser.parseString(response.body()).getAsJsonObject();
    }
}
