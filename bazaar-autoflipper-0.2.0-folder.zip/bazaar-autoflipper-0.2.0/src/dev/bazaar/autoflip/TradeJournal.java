package dev.bazaar.autoflip;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** An uncertain confirmation is never repeated after a restart. */
final class TradeJournal {
    enum Side { NONE, BUY, HOLD, SELL }
    static final class Entry {
        Side side = Side.NONE;
        String serverHost = "";
        String productId = "";
        long quantity;
        double buyPrice;
        double sellPrice;
        long submittedAt;
    }
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final Path path = FabricLoader.getInstance().getConfigDir().resolve("autoflip-order.json");
    Entry load() {
        try {
            if (Files.exists(path)) try (Reader r = Files.newBufferedReader(path)) {
                Entry e = GSON.fromJson(r, Entry.class);
                if (e != null && e.side != null) return e;
            }
        } catch (Exception e) { System.err.println("[AutoFlip] Journal damaged: " + e); }
        return new Entry();
    }
    void save(Entry entry) {
        try {
            Files.createDirectories(path.getParent());
            try (Writer w = Files.newBufferedWriter(path)) { GSON.toJson(entry,w); }
        } catch (Exception e) { throw new IllegalStateException("Could not save pending transaction; refusing to trade",e); }
    }
}
