package dev.bazaar.autoflip;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Pure string parsing rules; no Minecraft classes (unit-testable). */
public final class MenuRules {
    private static final Pattern PURSE = Pattern.compile("(?i)(?:purse|piggy)\\W{0,12}?([0-9][0-9,]*(?:\\.[0-9]+)?)\\s*([kmbt]?)\\b");
    private static final Pattern WHOLE = Pattern.compile("(?<!\\d)([0-9][0-9,]*)(?!\\d)");
    private static final Pattern FILL = Pattern.compile("(?<![0-9])100(?:\\.0+)?\\s*%|fully\\s*filled|order\\s*(?:filled|complete)|100%\\s*filled", Pattern.CASE_INSENSITIVE);

    private MenuRules() { }
    public static String normalize(String s) {
        return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }
    public static String productName(String id) { return ItemKeys.primaryName(id); }
    public static boolean itemMatches(String itemTitle, String productId) {
        return ItemKeys.nameMatches(itemTitle, productId);
    }
    public static double parsePurse(String text) {
        StringBuilder clean = new StringBuilder();
        for (char ch : text.toCharArray()) {
            int type = Character.getType(ch);
            if (type == Character.FORMAT || type == Character.CONTROL) continue;   // zero-width / control chars
            clean.append(Character.isWhitespace(ch) || Character.isSpaceChar(ch) ? ' ' : ch);
        }
        Matcher m = PURSE.matcher(clean);
        if (!m.find()) return Double.NaN;
        double x = Double.parseDouble(m.group(1).replace(",", ""));
        String suffix = m.group(2).toLowerCase(Locale.ROOT);
        double factor = switch (suffix) { case "k" -> 1e3; case "m" -> 1e6; case "b" -> 1e9; case "t" -> 1e12; default -> 1; };
        return x * factor;
    }
    public static boolean fullyFilled(String text) {
        // Never treat an order as fully filled just because it says "click to collect".
        return FILL.matcher(text).find();
    }
    public static boolean buyOrder(String text) {
        return text.toLowerCase(Locale.ROOT).contains("buy order");
    }
    public static boolean sellOffer(String text) {
        String x = text.toLowerCase(Locale.ROOT);
        return x.contains("sell offer") || x.contains("sell order");
    }
    /** Returns -1 if the quantity cannot be determined reliably. */
    public static int presetQuantity(String name, String lore) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.contains("custom")) return -1;
        if (!(n.contains("stack") || n.contains("amount") || n.contains("one thousand") || n.contains("get me") || n.contains("buy") || n.contains("quantity"))) return -1;
        // Prefer an explicit quantity in lore, but ignore coins/prices.
        for (String line : lore.split("\\n")) {
            String l = line.toLowerCase(Locale.ROOT);
            if (l.contains("item") || l.contains("amount") || l.contains("quantity")) {
                Matcher m = WHOLE.matcher(l);
                if (m.find()) {
                    try { return Integer.parseInt(m.group(1).replace(",", "")); }
                    catch (NumberFormatException ignored) { }
                }
            }
        }
        // Only unambiguous labels; other presets need tooltip numbers.
        if (n.contains("one thousand")) return 1024;
        if (n.contains("a stack") || n.contains("one stack")) return 64;
        return -1;
    }
}
