package dev.bazaar.autoflip;

import java.util.OptionalDouble;
import net.minecraft.client.Minecraft;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.PlayerScoreEntry;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.PlayerTeam;

/** Account information is read from real in-game scoreboard/inventory packets. */
final class AccountReader {
    private static volatile String lastDump = "(scoreboard not read yet)";

    /** Looks at every scoreboard display slot and several text forms of every line. */
    static OptionalDouble purse(Minecraft mc) {
        if (mc.level == null || mc.player == null) return OptionalDouble.empty();
        Scoreboard board = mc.level.getScoreboard();
        OptionalDouble found = OptionalDouble.empty();
        StringBuilder dump = new StringBuilder();
        for (DisplaySlot slot : slots()) {
            Objective objective = board.getDisplayObjective(slot);
            if (objective == null) continue;
            dump.append('<').append(slot).append('>');
            for (PlayerScoreEntry entry : board.listPlayerScores(objective)) {
                String formatted = PlayerTeam.formatNameForTeam(board.getPlayersTeam(entry.owner()), entry.ownerName()).getString();
                String plain = entry.ownerName().getString();
                String owner = entry.owner();
                dump.append(" [").append(escape(formatted)).append(']');
                for (String text : new String[] { formatted, plain, owner }) {
                    double v = MenuRules.parsePurse(text);
                    if (Double.isFinite(v) && found.isEmpty()) found = OptionalDouble.of(v);
                }
            }
        }
        lastDump = dump.length() == 0 ? "(no scoreboard objective in any display slot)" : dump.toString();
        return found;
    }
    private static DisplaySlot[] slots() {
        try { return DisplaySlot.values(); }
        catch (Throwable t) { return new DisplaySlot[] { DisplaySlot.SIDEBAR }; }
    }
    /** Text for the chat warning, including what the mod actually saw. */
    static String noPurseMessage() {
        String d = lastDump;
        if (d.length() > 400) d = d.substring(0, 400) + "...";
        return "No 'Purse:' entry found; refusing to buy with unknown balance. Scoreboard seen: " + d;
    }
    private static String escape(String s) {
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c >= 32 && c < 127) b.append(c); else b.append(String.format("\\u%04x", (int) c));
        }
        return b.toString();
    }
    /** SNBT text of the stack's custom data (holds the SkyBlock 'id'), or null. */
    private static String customData(ItemStack stack) {
        try { Object d = stack.get(DataComponents.CUSTOM_DATA); return d == null ? null : d.toString(); }
        catch (Throwable t) { return null; }
    }
    static long count(Minecraft mc,String productId) {
        if (mc.player == null) return -1;
        long n=0;
        for (ItemStack stack : mc.player.getInventory().getNonEquipmentItems()) {
            if (stack.isEmpty()) continue;
            if (ItemKeys.stackMatches(stack.getHoverName().getString(), customData(stack), productId)) n+=stack.getCount();
        }
        return n;
    }
}
